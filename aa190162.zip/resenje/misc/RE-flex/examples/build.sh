#!/bin/sh
echo
echo "Building the examples"
make -f Make
echo
echo "OK"
