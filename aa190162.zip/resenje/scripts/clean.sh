TEST_DIR=../tests/test_a
rm -f ../asembler
rm -f ../linker
rm -f ../emulator
rm -f ../inc/asembler/lex.yy.h
rm -f ../src/asembler/lex.yy.cpp
rm -f ${TEST_DIR}/*.o
rm -f ${TEST_DIR}/*.txt
rm -f ${TEST_DIR}/*.hex
