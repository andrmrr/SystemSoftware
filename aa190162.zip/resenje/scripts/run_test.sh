#RUN
TEST_DIR=../tests/test_a
ASSEMBLER=../asembler
LINKER=../linker
EMULATOR=../emulator

${ASSEMBLER} -o ${TEST_DIR}/main.o ${TEST_DIR}/main.s
${ASSEMBLER} -o ${TEST_DIR}/math.o ${TEST_DIR}/math.s
${ASSEMBLER} -o ${TEST_DIR}/handler.o ${TEST_DIR}/handler.s
${ASSEMBLER} -o ${TEST_DIR}/isr_timer.o ${TEST_DIR}/isr_timer.s
${ASSEMBLER} -o ${TEST_DIR}/isr_terminal.o ${TEST_DIR}/isr_terminal.s
${ASSEMBLER} -o ${TEST_DIR}/isr_software.o ${TEST_DIR}/isr_software.s

${LINKER} -hex \
  -place=my_code@0x40000000 -place=math@0xF0000000 \
  -o ${TEST_DIR}/program.hex \
  ${TEST_DIR}/handler.o ${TEST_DIR}/math.o ${TEST_DIR}/main.o ${TEST_DIR}/isr_terminal.o \ 	     ${TEST_DIR}/isr_timer.o ${TEST_DIR}/isr_software.o
  
${EMULATOR} ${TEST_DIR}/program.hex
