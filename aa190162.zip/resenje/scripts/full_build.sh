#build lex.yy.h and lex.yy.cpp
../misc/RE-flex/bin/reflex ../misc/reflex.l -o ../src/asembler/lex.yy.cpp \
 --header-file=../inc/asembler/lex.yy.h
 
 #build the assembler tool
 c++ -I../inc/reflex/include -I../inc/asembler -g -o ../asembler \
../src/asembler/*.cpp ../inc/reflex/lib/libreflex.a

#build the linker tool
c++ -I../inc/linker -g -o ../linker ../src/linker/*.cpp

#build the emulator tool
c++ -I../inc/emulator -o ../emulator ../src/emulator/*.cpp
